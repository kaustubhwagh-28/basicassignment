package DisplayingNameBasedOnInput;
import java.util.Scanner;
public class DisplayingNameBasedOnInput {
 public static void display(int no)
 {
	for(int i=0;i< no;i++)
	{
		System.out.println("Kaustubh Wagh");
	}
 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 Scanner sobj=new Scanner(System.in);
System.out.println("Enter the number");
int no=sobj.nextInt();
display(no);


	}

}
