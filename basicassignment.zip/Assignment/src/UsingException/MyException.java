package UsingException;
//user defined exception
public class MyException extends Exception {
	private int detail;

    MyException(int a) {
            detail = a;
    }
    public String toString() {
        return "Invalid Input";

}
}
