package UsingException;
import java.util.*;
import java.io.*;
public class test {
	
	    private String str = "";

    TimerTask task = new TimerTask()
    {
        public void run()
        {
            if( str.equals("") )
            {
                System.out.println( "you input nothing. exit..." );
                System.exit( 0 );
            }
           
    }
    };
    public void getInput() throws Exception
    {
        Timer timer = new Timer();
        timer.schedule( task, 10*1000 );//using timer for taking the input in 10 secs

        System.out.println( "Input a number within 10 seconds: " );
        BufferedReader in = new BufferedReader(
        new InputStreamReader( System.in ) );
        str = in.readLine();

        timer.cancel();
        //System.out.println( "you have entered: "+ str );
        try {
        	int no=Integer.parseInt(str);
        	UsingException ue=new UsingException();
        	ue.display(no);
            }
        	catch(Exception e)
        	{
        		System.out.println("Invalid Input");
            	}
	    }
}

