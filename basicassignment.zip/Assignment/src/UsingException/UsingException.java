package UsingException;

import java.util.Scanner;

public class UsingException{

	public  void display(int no1)  throws MyException
	 {
		if(no1 <=0)
		{
			throw new MyException(no1);
		}
		for(int i=0;i< no1;i++)
		{
			System.out.println("Kaustubh Wagh");
	}
 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			
			(new test()).getInput();




		}
	
		catch(Exception e)
		{
			System.out.println("Invalid input");
			}
	


}
}