package DisplayingNameUsingDifferentTypeOfLoops;

public class Loops {
public static void loops(String Name)
{
	int j=0;
	int k=0;
	System.out.println("Using For Loop");
for(int i=0;i<10;i++)
{
	System.out.println(Name);
}
System.out.println("Using While Loop");
while(j<10)
{
	j++;
	System.out.println(Name);
}
System.out.println("Using do while");
	do {
		System.out.println(Name);
		k++;
	}while(k<10);
}
}
