package DisplayingNameUsingDifferentTypeOfLoops;
import java.util.*;
public class DisplayingNameUsingDifferentTypeOfLoops {

	public static void main(String[] args) {
		

Loops.loops("Kaustubh Wagh");
	}

}
